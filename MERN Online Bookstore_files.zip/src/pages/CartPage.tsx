import  { Link } from 'react-router-dom';
import { Trash, ShoppingCart, ChevronLeft, ChevronRight } from 'lucide-react';
import { useCart } from '../context/CartContext';

export default function CartPage() {
  const { items, removeFromCart, updateQuantity, totalItems, totalPrice } = useCart();

  if (items.length === 0) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 text-center">
        <div className="bg-white rounded-lg shadow-md p-8 max-w-2xl mx-auto">
          <ShoppingCart size={64} className="mx-auto text-gray-400 mb-4" />
          <h1 className="text-2xl font-bold text-gray-900 mb-4">Your Cart is Empty</h1>
          <p className="text-gray-600 mb-8">Looks like you haven't added any books to your cart yet.</p>
          <Link to="/books" className="btn btn-primary">
            Browse Books
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-8">Your Cart</h1>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Cart Items */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <ul className="divide-y divide-gray-200">
                {items.map(item => (
                  <li key={item.book.id} className="p-6">
                    <div className="flex flex-col sm:flex-row">
                      {/* Book Image */}
                      <div className="sm:w-24 h-24 flex-shrink-0 mb-4 sm:mb-0">
                        <img 
                          src={item.book.coverImage} 
                          alt={item.book.title} 
                          className="w-full h-full object-cover rounded"
                        />
                      </div>
                      
                      {/* Book Info */}
                      <div className="sm:ml-6 flex flex-col sm:flex-row flex-1 gap-4">
                        <div className="flex-1">
                          <h3 className="text-lg font-medium text-gray-900">
                            <Link to={`/books/${item.book.id}`} className="hover:text-primary-600">
                              {item.book.title}
                            </Link>
                          </h3>
                          <p className="mt-1 text-sm text-gray-500">{item.book.author}</p>
                          <p className="mt-1 text-sm font-medium text-gray-900">${item.book.price.toFixed(2)}</p>
                        </div>
                        
                        {/* Quantity and Remove */}
                        <div className="flex items-center">
                          <div className="flex items-center border border-gray-300 rounded">
                            <button 
                              onClick={() => updateQuantity(item.book.id, item.quantity - 1)}
                              className="px-2 py-1 text-gray-600 hover:bg-gray-100"
                              aria-label="Decrease quantity"
                            >
                              <ChevronLeft size={16} />
                            </button>
                            <span className="w-8 text-center">{item.quantity}</span>
                            <button 
                              onClick={() => updateQuantity(item.book.id, item.quantity + 1)}
                              className="px-2 py-1 text-gray-600 hover:bg-gray-100"
                              aria-label="Increase quantity"
                            >
                              <ChevronRight size={16} />
                            </button>
                          </div>
                          <button 
                            onClick={() => removeFromCart(item.book.id)}
                            className="ml-4 text-red-500 hover:text-red-700"
                            aria-label={`Remove ${item.book.title} from cart`}
                          >
                            <Trash size={18} />
                          </button>
                        </div>
                      </div>
                    </div>
                  </li>
                ))}
              </ul>
            </div>
            
            <div className="mt-8">
              <Link to="/books" className="inline-flex items-center text-primary-600 hover:text-primary-700">
                <ChevronLeft size={16} className="mr-1" />
                Continue Shopping
              </Link>
            </div>
          </div>
          
          {/* Order Summary */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-lg shadow-md p-6 sticky top-20">
              <h2 className="text-lg font-medium text-gray-900 mb-6">Order Summary</h2>
              
              <div className="space-y-4">
                <div className="flex justify-between">
                  <span className="text-gray-600">Subtotal ({totalItems} items)</span>
                  <span className="text-gray-900 font-medium">${totalPrice.toFixed(2)}</span>
                </div>
                
                <div className="flex justify-between">
                  <span className="text-gray-600">Shipping</span>
                  <span className="text-gray-900 font-medium">Free</span>
                </div>
                
                <div className="flex justify-between">
                  <span className="text-gray-600">Tax</span>
                  <span className="text-gray-900 font-medium">${(totalPrice * 0.08).toFixed(2)}</span>
                </div>
                
                <div className="border-t border-gray-200 pt-4 flex justify-between">
                  <span className="text-lg font-bold text-gray-900">Total</span>
                  <span className="text-lg font-bold text-gray-900">
                    ${(totalPrice + totalPrice * 0.08).toFixed(2)}
                  </span>
                </div>
              </div>
              
              <div className="mt-6">
                <Link 
                  to="/checkout" 
                  className="btn btn-primary w-full py-3 text-center"
                >
                  Proceed to Checkout
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
  