import  { useState } from 'react';
import { User, Edit, Package, Mail, LogOut } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useNavigate } from 'react-router-dom';

export default function ProfilePage() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('profile');
  
  // Mock orders data
  const orders = [
    {
      id: '1',
      date: '2023-06-15',
      total: 54.97,
      status: 'Delivered',
      items: [
        { title: 'The Midnight Library', quantity: 1, price: 18.99 },
        { title: 'Atomic Habits', quantity: 1, price: 16.99 },
        { title: 'Project Hail Mary', quantity: 1, price: 18.99 }
      ]
    },
    {
      id: '2',
      date: '2023-05-22',
      total: 29.98,
      status: 'Delivered',
      items: [
        { title: 'Dune', quantity: 1, price: 12.99 },
        { title: 'Where the Crawdads Sing', quantity: 1, price: 16.99 }
      ]
    }
  ];

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  return (
    <div className="bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-8">My Account</h1>
        
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Sidebar */}
          <div className="md:col-span-1">
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <div className="p-6 text-center border-b border-gray-200">
                <div className="w-20 h-20 bg-primary-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <User size={32} className="text-primary-600" />
                </div>
                <h2 className="text-xl font-semibold text-gray-900">{user?.name}</h2>
                <p className="text-gray-600">{user?.email}</p>
              </div>
              
              <nav className="p-4">
                <ul className="space-y-2">
                  <li>
                    <button
                      className={`w-full flex items-center px-4 py-2 rounded-md ${
                        activeTab === 'profile'
                          ? 'bg-primary-50 text-primary-700'
                          : 'text-gray-700 hover:bg-gray-100'
                      }`}
                      onClick={() => setActiveTab('profile')}
                    >
                      <User size={18} className="mr-3" />
                      Profile Information
                    </button>
                  </li>
                  <li>
                    <button
                      className={`w-full flex items-center px-4 py-2 rounded-md ${
                        activeTab === 'orders'
                          ? 'bg-primary-50 text-primary-700'
                          : 'text-gray-700 hover:bg-gray-100'
                      }`}
                      onClick={() => setActiveTab('orders')}
                    >
                      <Package size={18} className="mr-3" />
                      Order History
                    </button>
                  </li>
                  <li>
                    <button
                      className="w-full flex items-center px-4 py-2 rounded-md text-gray-700 hover:bg-gray-100"
                      onClick={handleLogout}
                    >
                      <LogOut size={18} className="mr-3" />
                      Sign Out
                    </button>
                  </li>
                </ul>
              </nav>
            </div>
          </div>
          
          {/* Main Content */}
          <div className="md:col-span-3">
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              {activeTab === 'profile' && (
                <div className="p-6">
                  <div className="flex items-center justify-between mb-6">
                    <h2 className="text-xl font-semibold text-gray-900">Profile Information</h2>
                    <button className="flex items-center text-primary-600 hover:text-primary-700">
                      <Edit size={18} className="mr-1" />
                      Edit
                    </button>
                  </div>
                  
                  <div className="space-y-6">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Name
                      </label>
                      <input
                        type="text"
                        value={user?.name}
                        readOnly
                        className="input w-full bg-gray-50"
                      />
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Email Address
                      </label>
                      <div className="flex items-center">
                        <Mail size={18} className="text-gray-400 mr-2" />
                        <input
                          type="email"
                          value={user?.email}
                          readOnly
                          className="input w-full bg-gray-50"
                        />
                      </div>
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Default Shipping Address
                      </label>
                      <textarea
                        readOnly
                        className="input w-full bg-gray-50 h-24"
                        defaultValue="123 Bookstore Ave, Reading, CA 12345, United States"
                      />
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Password
                      </label>
                      <input
                        type="password"
                        value="••••••••"
                        readOnly
                        className="input w-full bg-gray-50"
                      />
                    </div>
                    
                    <div className="pt-4 border-t border-gray-200">
                      <h3 className="text-lg font-medium text-gray-900 mb-4">Preferences</h3>
                      
                      <div className="space-y-3">
                        <div className="flex items-center">
                          <input
                            id="newsletter"
                            type="checkbox"
                            className="h-4 w-4 text-primary-600 border-gray-300 rounded"
                            defaultChecked
                          />
                          <label htmlFor="newsletter" className="ml-2 block text-sm text-gray-700">
                            Receive email notifications about new releases and promotions
                          </label>
                        </div>
                        
                        <div className="flex items-center">
                          <input
                            id="order-updates"
                            type="checkbox"
                            className="h-4 w-4 text-primary-600 border-gray-300 rounded"
                            defaultChecked
                          />
                          <label htmlFor="order-updates" className="ml-2 block text-sm text-gray-700">
                            Receive order status updates via email
                          </label>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}
              
              {activeTab === 'orders' && (
                <div className="p-6">
                  <h2 className="text-xl font-semibold text-gray-900 mb-6">Order History</h2>
                  
                  {orders.length > 0 ? (
                    <div className="space-y-6">
                      {orders.map(order => (
                        <div key={order.id} className="border border-gray-200 rounded-md overflow-hidden">
                          <div className="bg-gray-50 px-4 py-3 border-b border-gray-200">
                            <div className="flex flex-wrap justify-between items-center">
                              <div>
                                <span className="text-sm text-gray-500">Order placed</span>
                                <p className="text-sm font-medium text-gray-900">{order.date}</p>
                              </div>
                              
                              <div>
                                <span className="text-sm text-gray-500">Total</span>
                                <p className="text-sm font-medium text-gray-900">${order.total.toFixed(2)}</p>
                              </div>
                              
                              <div>
                                <span className="text-sm text-gray-500">Order #</span>
                                <p className="text-sm font-medium text-gray-900">{order.id}</p>
                              </div>
                              
                              <div>
                                <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                                  order.status === 'Delivered' 
                                    ? 'bg-green-100 text-green-800' 
                                    : 'bg-blue-100 text-blue-800'
                                }`}>
                                  {order.status}
                                </span>
                              </div>
                            </div>
                          </div>
                          
                          <div className="p-4">
                            <h3 className="text-sm font-medium text-gray-900 mb-3">Items in this order</h3>
                            <ul className="divide-y divide-gray-200">
                              {order.items.map((item, idx) => (
                                <li key={idx} className="py-3 flex justify-between">
                                  <div className="flex items-center">
                                    <span className="text-sm font-medium text-gray-900">{item.title}</span>
                                    <span className="ml-2 text-sm text-gray-500">Qty: {item.quantity}</span>
                                  </div>
                                  <span className="text-sm font-medium text-gray-900">${item.price.toFixed(2)}</span>
                                </li>
                              ))}
                            </ul>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="bg-gray-50 rounded-md p-6 text-center">
                      <Package size={48} className="mx-auto text-gray-400 mb-4" />
                      <h3 className="text-lg font-medium text-gray-900 mb-1">No orders yet</h3>
                      <p className="text-gray-500 mb-4">When you place your first order, it will appear here.</p>
                      <button 
                        onClick={() => navigate('/books')} 
                        className="btn btn-primary"
                      >
                        Browse Books
                      </button>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
  