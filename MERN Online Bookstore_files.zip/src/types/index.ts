export  interface Book {
  id: string;
  title: string;
  author: string;
  price: number;
  coverImage: string;
  description: string;
  category: string;
  rating: number;
  stock: number;
}

export interface User {
  id: string;
  name: string;
  email: string;
}

export interface Order {
  id: string;
  items: Array<{
    book: Book;
    quantity: number;
  }>;
  totalAmount: number;
  date: string;
  status: 'pending' | 'processing' | 'shipped' | 'delivered';
}
  