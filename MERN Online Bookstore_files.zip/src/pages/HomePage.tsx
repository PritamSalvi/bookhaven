import  { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Book } from 'lucide-react';
import BookCard from '../components/BookCard';
import { books } from '../data/books';

export default function HomePage() {
  const [featuredBooks, setFeaturedBooks] = useState(books.slice(0, 4));

  useEffect(() => {
    // In a real app, you might fetch featured books from an API
    setFeaturedBooks(books.slice(0, 4));
  }, []);

  return (
    <div>
      {/* Hero Section */}
      <section className="relative">
        <div className="h-[600px] overflow-hidden">
          <img 
            src="https://images.unsplash.com/photo-1664935035283-c2580f4196a2?ixid=M3w3MjUzNDh8MHwxfHNlYXJjaHwxfHxib29rc3RvcmUlMjBzaGVsdmVzJTIwYm9va3N8ZW58MHx8fHwxNzQ5NjU4NDA5fDA&ixlib=rb-4.1.0&fit=fillmax&h=600&w=800" 
            alt="Bookstore with shelves full of books" 
            className="w-full h-full object-cover brightness-50"
          />
        </div>
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="text-center max-w-4xl px-4">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-6">
              Discover Your Next Favorite Book
            </h1>
            <p className="text-xl text-white mb-8">
              Explore our vast collection of books across all genres at unbeatable prices
            </p>
            <Link to="/books" className="btn btn-primary text-lg px-8 py-3">
              Browse Books
            </Link>
          </div>
        </div>
      </section>

      {/* Featured Books Section */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center mb-8">
            <h2 className="text-3xl font-bold text-gray-900">Featured Books</h2>
            <Link to="/books" className="flex items-center text-primary-600 hover:text-primary-700">
              View All <ArrowRight size={18} className="ml-1" />
            </Link>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {featuredBooks.map(book => (
              <BookCard key={book.id} book={book} />
            ))}
          </div>
        </div>
      </section>

      {/* Categories Section */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-gray-900 mb-8 text-center">
            Browse by Category
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {['Fiction', 'Non-Fiction', 'Self-Help', 'Science Fiction', 'Biography', 'Fantasy'].map(category => (
              <Link 
                key={category}
                to={`/books?category=${category}`}
                className="bg-white rounded-lg shadow-md p-8 text-center hover:shadow-lg transition-shadow"
              >
                <Book size={36} className="mx-auto mb-4 text-primary-600" />
                <h3 className="text-xl font-semibold text-gray-900">{category}</h3>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Why Choose Us Section */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-gray-900 mb-12 text-center">
            Why Choose BookHaven
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white rounded-lg shadow p-6 text-center">
              <div className="w-16 h-16 bg-primary-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <ShoppingCart size={24} className="text-primary-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Fast Shipping</h3>
              <p className="text-gray-600">Free shipping on orders over $35 with delivery in 2-3 business days</p>
            </div>
            <div className="bg-white rounded-lg shadow p-6 text-center">
              <div className="w-16 h-16 bg-primary-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <RefreshCw size={24} className="text-primary-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Easy Returns</h3>
              <p className="text-gray-600">30-day hassle-free return policy if you're not completely satisfied</p>
            </div>
            <div className="bg-white rounded-lg shadow p-6 text-center">
              <div className="w-16 h-16 bg-primary-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Users size={24} className="text-primary-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Dedicated Support</h3>
              <p className="text-gray-600">Our customer service team is available 24/7 to assist you</p>
            </div>
          </div>
        </div>
      </section>

      {/* Newsletter Section */}
      <section className="py-16 bg-primary-600">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-3xl font-bold text-white mb-4">
              Join Our Newsletter
            </h2>
            <p className="text-primary-100 mb-8 max-w-2xl mx-auto">
              Subscribe to get special offers, free giveaways, and once-in-a-lifetime deals.
            </p>
            <form className="max-w-md mx-auto flex">
              <input
                type="email"
                placeholder="Your email address"
                className="input flex-grow"
                required
              />
              <button type="submit" className="btn bg-white text-primary-600 hover:bg-gray-100 ml-2">
                Subscribe
              </button>
            </form>
          </div>
        </div>
      </section>
    </div>
  );
}

// Import the icons we're using
import { ShoppingCart, RefreshCw, Users } from 'lucide-react';
  