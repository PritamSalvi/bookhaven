import  { Link } from 'react-router-dom';
import { ShoppingCart, Star } from 'lucide-react';
import { Book } from '../types';
import { useCart } from '../context/CartContext';

interface BookCardProps {
  book: Book;
}

export default function BookCard({ book }: BookCardProps) {
  const { addToCart } = useCart();

  return (
    <div className="card h-full flex flex-col">
      <Link to={`/books/${book.id}`} className="block overflow-hidden h-48">
        <img
          src={book.coverImage}
          alt={book.title}
          className="w-full h-full object-cover transition-transform hover:scale-105"
        />
      </Link>
      <div className="p-4 flex-grow flex flex-col">
        <Link to={`/books/${book.id}`}>
          <h3 className="text-lg font-semibold text-gray-900 hover:text-primary-600">{book.title}</h3>
        </Link>
        <p className="text-gray-600">{book.author}</p>
        <div className="flex items-center mt-2">
          <div className="flex items-center">
            {[...Array(5)].map((_, i) => (
              <Star
                key={i}
                size={16}
                className={`${
                  i < Math.floor(book.rating) 
                    ? 'text-yellow-400 fill-current' 
                    : 'text-gray-300'
                }`}
              />
            ))}
          </div>
          <span className="ml-1 text-sm text-gray-600">({book.rating})</span>
        </div>
        <div className="mt-auto pt-4 flex items-center justify-between">
          <span className="text-lg font-bold text-gray-900">${book.price.toFixed(2)}</span>
          <button 
            onClick={() => addToCart(book)} 
            className="btn btn-primary flex items-center"
            aria-label={`Add ${book.title} to cart`}
          >
            <ShoppingCart size={16} className="mr-1" />
            Add
          </button>
        </div>
      </div>
    </div>
  );
}
  