import  { Book } from '../types';

export const books: Book[] = [
  {
    id: '1',
    title: 'The Midnight Library',
    author: 'Matt Haig',
    price: 18.99,
    coverImage: 'https://images.unsplash.com/photo-1544947950-fa07a98d237f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8OHx8Ym9vayUyMGNvdmVyfGVufDB8fDB8fHww&auto=format&fit=crop&w=500&q=60',
    description: 'Between life and death there is a library, and within that library, the shelves go on forever. Every book provides a chance to try another life you could have lived.',
    category: 'Fiction',
    rating: 4.5,
    stock: 15
  },
  {
    id: '2',
    title: 'Atomic Habits',
    author: 'James Clear',
    price: 16.99,
    coverImage: 'https://images.unsplash.com/photo-1589998059171-988d887df646?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTJ8fGJvb2slMjBjb3ZlcnxlbnwwfHwwfHx8MA%3D%3D&auto=format&fit=crop&w=500&q=60',
    description: 'No matter your goals, Atomic Habits offers a proven framework for improving every day.',
    category: 'Self-Help',
    rating: 4.8,
    stock: 22
  },
  {
    id: '3',
    title: 'The Song of Achilles',
    author: 'Madeline Miller',
    price: 14.95,
    coverImage: 'https://images.unsplash.com/photo-1629992101753-56d196c8aabb?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTR8fGJvb2slMjBjb3ZlcnxlbnwwfHwwfHx8MA%3D%3D&auto=format&fit=crop&w=500&q=60',
    description: 'A tale of gods, kings, immortal fame, and the human heart, The Song of Achilles is a dazzling literary feat.',
    category: 'Fiction',
    rating: 4.7,
    stock: 10
  },
  {
    id: '4',
    title: 'Educated',
    author: 'Tara Westover',
    price: 15.99,
    coverImage: 'https://images.unsplash.com/photo-1633477189729-9290b3261d0a?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTh8fGJvb2slMjBjb3ZlcnxlbnwwfHwwfHx8MA%3D%3D&auto=format&fit=crop&w=500&q=60',
    description: 'A memoir about a young girl who, kept out of school, leaves her survivalist family and goes on to earn a PhD from Cambridge University.',
    category: 'Biography',
    rating: 4.6,
    stock: 13
  },
  {
    id: '5',
    title: 'Project Hail Mary',
    author: 'Andy Weir',
    price: 19.99,
    coverImage: 'https://images.unsplash.com/photo-1531072901881-d644216d4bf9?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MjB8fGJvb2slMjBjb3ZlcnxlbnwwfHwwfHx8MA%3D%3D&auto=format&fit=crop&w=500&q=60',
    description: 'A lone astronaut must save the earth from disaster in this incredible new science-based thriller from the #1 New York Times bestselling author of The Martian.',
    category: 'Science Fiction',
    rating: 4.9,
    stock: 8
  },
  {
    id: '6',
    title: 'Dune',
    author: 'Frank Herbert',
    price: 12.99,
    coverImage: 'https://images.unsplash.com/photo-1621351183012-e2f9972dd9bf?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MjJ8fGJvb2slMjBjb3ZlcnxlbnwwfHwwfHx8MA%3D%3D&auto=format&fit=crop&w=500&q=60',
    description: 'Set on the desert planet Arrakis, Dune is the story of the boy Paul Atreides, heir to a noble family tasked with ruling an inhospitable world.',
    category: 'Science Fiction',
    rating: 4.7,
    stock: 20
  },
  {
    id: '7',
    title: 'The Invisible Life of Addie LaRue',
    author: 'V.E. Schwab',
    price: 17.99,
    coverImage: 'https://images.unsplash.com/photo-1512820790803-83ca734da794?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MjZ8fGJvb2slMjBjb3ZlcnxlbnwwfHwwfHx8MA%3D%3D&auto=format&fit=crop&w=500&q=60',
    description: 'A Life No One Will Remember. A Story You Will Never Forget.',
    category: 'Fantasy',
    rating: 4.4,
    stock: 9
  },
  {
    id: '8',
    title: 'Where the Crawdads Sing',
    author: 'Delia Owens',
    price: 13.99,
    coverImage: 'https://images.unsplash.com/photo-1629992101753-56d196c8aabb?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTR8fGJvb2slMjBjb3ZlcnxlbnwwfHwwfHx8MA%3D%3D&auto=format&fit=crop&w=500&q=60',
    description: 'A novel about a young woman who, abandoned by her family, raises herself in the marshes of the deep South.',
    category: 'Fiction',
    rating: 4.6,
    stock: 15
  }
];

export const categories = [...new Set(books.map(book => book.category))];
  