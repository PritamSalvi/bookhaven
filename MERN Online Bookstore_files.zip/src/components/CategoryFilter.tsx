import  { Filter } from 'lucide-react';

interface CategoryFilterProps {
  categories: string[];
  selectedCategory: string | null;
  onSelectCategory: (category: string | null) => void;
}

export default function CategoryFilter({ 
  categories, 
  selectedCategory, 
  onSelectCategory 
}: CategoryFilterProps) {
  return (
    <div className="mb-6">
      <div className="flex items-center mb-3">
        <Filter size={18} className="mr-2 text-gray-700" />
        <h3 className="text-lg font-medium text-gray-900">Categories</h3>
      </div>
      
      <div className="space-y-2">
        <button
          className={`block w-full text-left px-3 py-2 rounded ${
            selectedCategory === null
              ? 'bg-primary-100 text-primary-700 font-medium'
              : 'text-gray-700 hover:bg-gray-100'
          }`}
          onClick={() => onSelectCategory(null)}
        >
          All Categories
        </button>
        
        {categories.map(category => (
          <button
            key={category}
            className={`block w-full text-left px-3 py-2 rounded ${
              selectedCategory === category
                ? 'bg-primary-100 text-primary-700 font-medium'
                : 'text-gray-700 hover:bg-gray-100'
            }`}
            onClick={() => onSelectCategory(category)}
          >
            {category}
          </button>
        ))}
      </div>
    </div>
  );
}
  