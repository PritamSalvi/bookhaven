import  { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { ShoppingCart, Star, ChevronLeft, Check, AlertCircle } from 'lucide-react';
import { useCart } from '../context/CartContext';
import { books } from '../data/books';
import { Book } from '../types';

export default function BookDetailPage() {
  const { id } = useParams<{ id: string }>();
  const [book, setBook] = useState<Book | null>(null);
  const [loading, setLoading] = useState(true);
  const [quantity, setQuantity] = useState(1);
  const { addToCart } = useCart();

  useEffect(() => {
    // In a real app, this would be an API call
    const foundBook = books.find(b => b.id === id);
    setBook(foundBook || null);
    setLoading(false);
  }, [id]);

  const handleAddToCart = () => {
    if (book) {
      for (let i = 0; i < quantity; i++) {
        addToCart(book);
      }
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary-600"></div>
      </div>
    );
  }

  if (!book) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 text-center">
        <AlertCircle size={48} className="mx-auto text-red-500 mb-4" />
        <h1 className="text-2xl font-bold text-gray-900 mb-4">Book Not Found</h1>
        <p className="text-gray-600 mb-8">The book you're looking for doesn't exist or has been removed.</p>
        <Link to="/books" className="btn btn-primary">
          Browse Other Books
        </Link>
      </div>
    );
  }

  return (
    <div className="bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-6">
          <Link to="/books" className="inline-flex items-center text-primary-600 hover:text-primary-700">
            <ChevronLeft size={16} className="mr-1" />
            Back to Books
          </Link>
        </div>
        
        <div className="bg-white rounded-lg shadow-md overflow-hidden">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 p-8">
            {/* Book Image */}
            <div className="lg:col-span-1">
              <img 
                src={book.coverImage} 
                alt={book.title} 
                className="w-full rounded-lg shadow-lg"
              />
            </div>
            
            {/* Book Info */}
            <div className="lg:col-span-2">
              <h1 className="text-3xl font-bold text-gray-900 mb-2">{book.title}</h1>
              <p className="text-xl text-gray-600 mb-4">by {book.author}</p>
              
              {/* Rating */}
              <div className="flex items-center mb-4">
                <div className="flex items-center">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      size={20}
                      className={`${
                        i < Math.floor(book.rating) 
                          ? 'text-yellow-400 fill-current' 
                          : 'text-gray-300'
                      }`}
                    />
                  ))}
                </div>
                <span className="ml-2 text-gray-600">({book.rating})</span>
              </div>
              
              {/* Price */}
              <div className="text-2xl font-bold text-gray-900 mb-4">
                ${book.price.toFixed(2)}
              </div>
              
              {/* Availability */}
              <div className="mb-6">
                {book.stock > 0 ? (
                  <div className="flex items-center text-green-600">
                    <Check size={18} className="mr-2" />
                    <span>In Stock ({book.stock} available)</span>
                  </div>
                ) : (
                  <div className="flex items-center text-red-600">
                    <AlertCircle size={18} className="mr-2" />
                    <span>Out of Stock</span>
                  </div>
                )}
              </div>
              
              {/* Description */}
              <div className="mb-8">
                <h2 className="text-xl font-semibold text-gray-900 mb-2">Description</h2>
                <p className="text-gray-700">{book.description}</p>
              </div>
              
              {/* Add to Cart */}
              <div className="flex items-center">
                <div className="mr-4">
                  <label htmlFor="quantity" className="sr-only">Quantity</label>
                  <div className="flex items-center border border-gray-300 rounded">
                    <button 
                      onClick={() => setQuantity(prev => Math.max(1, prev - 1))}
                      className="px-3 py-1 text-gray-600 hover:bg-gray-100"
                      aria-label="Decrease quantity"
                    >
                      -
                    </button>
                    <input
                      type="number"
                      id="quantity"
                      value={quantity}
                      onChange={(e) => setQuantity(Math.max(1, parseInt(e.target.value) || 1))}
                      className="w-12 text-center border-none focus:ring-0"
                      min="1"
                    />
                    <button 
                      onClick={() => setQuantity(prev => prev + 1)}
                      className="px-3 py-1 text-gray-600 hover:bg-gray-100"
                      aria-label="Increase quantity"
                    >
                      +
                    </button>
                  </div>
                </div>
                <button 
                  onClick={handleAddToCart} 
                  className="btn btn-primary flex items-center"
                  disabled={book.stock === 0}
                >
                  <ShoppingCart size={18} className="mr-2" />
                  Add to Cart
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
  